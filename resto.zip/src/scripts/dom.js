import Initialize from './initialize';

document.addEventListener('DOMContentLoaded', () => {
  Initialize();
});
